package json;

public class GsonSerializer extends JsonSerializer {

    @Override
    public <T> String serialize(T _object) {
        return null;
    }

    @Override
    public <T> T deserialize(String _json, Class<T> _classType) {
        return null;
    }
}
