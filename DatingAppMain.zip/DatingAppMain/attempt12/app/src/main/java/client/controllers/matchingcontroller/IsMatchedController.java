package client.controllers.matchingcontroller;

import shared.datapersistence.Profile;

public class IsMatchedController {
    private static Profile originialProfile;



}
