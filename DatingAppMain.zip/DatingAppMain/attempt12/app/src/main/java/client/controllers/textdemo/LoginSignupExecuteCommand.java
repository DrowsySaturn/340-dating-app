package client.controllers.textdemo;

public class LoginSignupExecuteCommand {
    final public static int LOGIN_IN = 2;
    final public static int SIGN_UP = 1;
    final public static int EXIT = 0;
}
