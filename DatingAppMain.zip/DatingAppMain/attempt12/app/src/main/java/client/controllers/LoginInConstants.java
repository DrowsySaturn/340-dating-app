package client.controllers;

public class LoginInConstants {
    public final static boolean IS_ACTIVE = true;
    public final static boolean IS_ADMIN = true;
    public final static boolean NOT_ACTIVE = false;
    public final static boolean NOT_ADMIN = false;
}
