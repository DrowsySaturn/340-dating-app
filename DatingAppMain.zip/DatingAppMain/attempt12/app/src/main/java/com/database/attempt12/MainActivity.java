package com.database.attempt12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    LinearLayout parent;
    Button b;
    View space;
    LinearLayout bar;
    HorizontalScrollView lineSpace;
    LinearLayout.LayoutParams vidView = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_menu);
    }

    public void loadSearch(View view)
    {
        /*
         *as of this moment the int[] data is a test value upon connection with the model will modify accordingly.
         */
        int[] data = new int[20];
        setContentView(R.layout.find_person);
        parent = findViewById(R.id.scroll);


        /*
         *Sets up the initial view within the find person layout.
         */
        for(int i=0;i< data.length;i++)
        {
            /*
             *On even groups sets up new horizontal bar and pushes to the vertical scroll bar, after
             * which it pushes the new clickable person.
             * On odds it will add a simple space to that horizontal bar before pushing a new clickable person.
             */

            if(i%2 == 1)
            {

                space = new View(MainActivity.this);
                space.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                space.setId(i);
                space.getLayoutParams().width=50;
                bar.addView(space);
            }
            else
            {
                bar = new LinearLayout(MainActivity.this);
                bar.setId(i);
                bar.setHorizontalScrollBarEnabled(true);
                parent.addView(bar);
            }

            b = new Button(MainActivity.this);
            b.setLayoutParams(vidView);
            b.setId(i);
            b.setText("" + (i + 1));
            b.setTag(1);
            b.getLayoutParams().width=500;
            b.getLayoutParams().height=250;
            bar.addView(b);
        }
    }
    /*
     *Loads matches layout upon button event.
     */
    public void loadMatches(View view)
    {
        setContentView(R.layout.matches);

    }
    /*
     *Loads profile layout upon button event.
     */
    public void loadProfile(View view)
    {
        setContentView(R.layout.profile);
    }
    /*
     *Loads recording layout upon button event.
     */
    public void loadRecording(View view)
    {
        setContentView(R.layout.recording);
    }
    /*
     *Loads main menu layout upon button event.
     */
    public void loadMain(View view)
    {
        setContentView(R.layout.main_menu);
    }
    /*
     *Loads settings layout upon button event.
     */
    public void loadSettings(View view)
    {
        setContentView(R.layout.settings);
    }
}
