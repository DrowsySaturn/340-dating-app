package eventsinterfaces.events;

public interface Event {
    public void fireEvent();
    public String getName();
}
